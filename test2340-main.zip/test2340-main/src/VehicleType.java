public enum VehicleType {
    SBAHN,
    UBAHN,
    BUS,
    TRAM
}